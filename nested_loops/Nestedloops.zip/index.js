for(var family=1;family<=4;family++)
{
for(var gappas=1;gappas<=10;gappas++)
 {
  console.log("Gol-gappa0", gappas);
 }
}
