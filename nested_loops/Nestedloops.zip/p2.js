//Father : son village
// Father has 20 farms
//son have to put seed in 20 farms
for(var father =1;father<=20;father++){
  var bag = "";
for(var son= 1;son<=10;son++)

console.log("Farm", father,bag);
}