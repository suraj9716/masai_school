for(var prithviraj =1;prithviraj<=10;prithviraj++){
  for(var ashoka =1;ashoka<=10;ashoka++){
    if(prithviraj<ashoka){
      break;
    }
    console.log("prithviraj =",prithviraj,"ashoka =",ashoka)
  }
}