for (var father =1;father<=5;father++){
for (var son =1;son<=10;son++){
  console.log("Father", father,"Run",son)
}
}