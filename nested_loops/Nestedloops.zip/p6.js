for(var father =1;father<=5;father++){
  var bag = "";
for(var son= 1;son<=father;son++)
{
  bag = bag + son+" ";
}
console.log("Farm", father,bag);
}
for(var father =4;father>=1;father--){
  var bag = "";
for(var son= 1;son<=father;son++)
{
  bag = bag + son+" ";
}
console.log("Farm", father,bag);
}