var bag = "";
for(var son = 1;son<=10;son++){
  bag = bag + "*"; // concatination
}
console.log(bag)