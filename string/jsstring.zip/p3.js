var name = "masai";
var jhola = "";
for(var i =0;i<name.length;i++){
  jhola = jhola + name[i];
}
console.log(jhola)

console.log("_______________________")
var item = ["M","a","s","a","i"];
for(var j =0;j<item.length;j++){
  console.log(item[j]);
}