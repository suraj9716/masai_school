var str = "Masai School";
console.log(str.length)