// change the name of first letter
// strings are immutable you cannot change string like array
// array
var name = ["A","B","C","D"];
name[0] = "Z";
console.log(name);

// strings

var name2 = "ABCD";
name2[0] = "Z";
console.log(name2)