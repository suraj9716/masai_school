var name = "suraj singh";
var size = name.length;
console.log(size)
for(var i =0;i<=size-1;i++){
  console.log(name[i])
}