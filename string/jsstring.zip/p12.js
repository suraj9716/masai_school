// count k

var name = "Kakaskkkkkkhi";
var count = 0;
for(var i=0;i<name.length;i++){
  if(name[i] == "K" ||name[i]=="k")
  
  count++;
}
console.log(count);