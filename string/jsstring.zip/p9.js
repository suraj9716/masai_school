// print in reverse
var bag = "";
var name = "Ram pal sharma";
for(var i=name.length-1;i>=0;i--){
  bag = bag + name[i];
}
console.log(bag);