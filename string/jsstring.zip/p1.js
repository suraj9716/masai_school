// where you use string

var password = "abc1tgf";

if(password.length<6){
  console.log("choose a password more than 6 character")
}
else{
  console.log("saved")
}