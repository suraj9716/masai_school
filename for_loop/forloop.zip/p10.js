var bag = " ";
for(var i =5;i>=1;i--)
  {
    bag = bag +i;
  }
console.log(bag);