var count = 0;
for(var i =1;i<=100;i++)
{
  if(i==50){
    break;
  }
  count++;
}
console.log(count);