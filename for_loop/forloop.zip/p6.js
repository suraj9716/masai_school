//continue

for(var i =1;i<=100;i++){
  console.log("before break",i);
 if(i>50){
   console.log("bomb fat gaya");
   continue;
 }
  console.log("after break",i);
}