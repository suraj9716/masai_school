//sum of even no

var sum = 0;
for( var i =0; i<=10;i++)
{
  if(i%2==0)
  {
    sum = sum+i;
  }
  
}
console.log(sum);