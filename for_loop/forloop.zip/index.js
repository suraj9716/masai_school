for(var i =0;i<=5;i++){
  console.log("hello");
}

for(var i=0;i<=10;i=i+2){
  console.log("hi");
} //this code goes to infinite loop