// find factorial of a number

var fact = 1;
for(var i=1;i<=5;i++){
  fact = fact*i;
}
console.log(fact);