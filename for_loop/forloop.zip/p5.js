//break

for(var i =1;i<=100;i++){
  console.log("before break",i);
 if(i>25){
   console.log("bomb fat gaya");
   break;
 }
  console.log("after break",i);
}