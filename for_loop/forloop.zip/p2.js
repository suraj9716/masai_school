//sum from 50-100
var sum = 0;
for(var i =50;i<=100;i++){
  sum = sum+i;
  console.log(sum);
}
console.log(sum);