//for every number find mod 10
for(var i =1;i<=10;i++)
{
  console.log(i%10)
}